<br>
<div class="container mt-5 text-center">
  <h1 class="mt-5 font-weight-bold">TIDAK BISA MEMINJAM RUANGAN <i class="far fa-sad-tear"></i></h1>
  <h5>Silahkan Login untuk meminjam ruangan</h5>
  <br>
  <a href="<?= base_url('auth'); ?>">Login <i class="fas fa-sign-in-alt"></i></a>

  <br><br><br>
  <br><br><br>
  <br><br>
</div>