<br>
<div class="container mt-5 text-center">
    <h1 class="display-2 mt-5 font-weight-bold text-danger">404<i class="far fa-sad-tear pl-2"></i></h1>
    <h5>Halaman Tidak bisa di Akses</h5>
    <br>
    <a href="<?= base_url(); ?>">kembali ke halaman home <i class="fas fa-undo"></i></a>
    <br><br><br>
    <br><br><br>
    <br>
</div>