<script>
  /**
   * Fungsi sementara untuk melakukan reload data setiap 1 menit, proses ini akan digantikan oleh cronjobs
   */

  if (document.documentURI.indexOf("/autochange") !== -1) {
    setTimeout(function() {
      location.reload();
    }, 60000);
  }
</script>